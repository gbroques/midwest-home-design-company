package application.model;

public class Traditional extends House {

	public Traditional() {
		super("Traditional");
		setBedrooms(3);
		setBathrooms(2);
		setTemplateBasicRate(3300);
	}

}
