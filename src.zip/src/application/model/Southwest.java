package application.model;

public class Southwest extends House {

	public Southwest() {
		super("Southwest");
		setBedrooms(3);
		setBathrooms(2);
		setTemplateBasicRate(3600);
	}

}