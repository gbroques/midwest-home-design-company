package application.model;

public class Mountain extends House {

	public Mountain() {
		super("Mountain");
		setBedrooms(3);
		setBathrooms(2);
		setTemplateBasicRate(3500);
	}

}