package application.model;

public class European extends House {

	public European() {
		super("European");
		setBedrooms(2);
		setBathrooms(2);
		setTemplateBasicRate(4700);
	}
}