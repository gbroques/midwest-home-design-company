package application.model;

public class Modern extends House {

	public Modern() {
		super("Modern");
		setBedrooms(2);
		setBathrooms(1.5);
		setTemplateBasicRate(4200);
	}
}