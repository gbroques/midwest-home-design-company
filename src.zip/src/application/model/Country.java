package application.model;

public class Country extends House {

	public Country() {
		super("Country");
		setBedrooms(3);
		setBathrooms(3);
		setTemplateBasicRate(3000);
	}

}