package application.model;

public class Victorian extends House {

	public Victorian() {
		super("Victorian");
		setBedrooms(3);
		setBathrooms(2.5);
		setTemplateBasicRate(3200);
	}

}